Be advice in uploads/server is for the dev and publiser side in it func like upload a new game ,
upload new version for a game , upload the "media" for a game 