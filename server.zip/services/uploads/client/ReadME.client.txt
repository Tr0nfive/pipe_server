BE advice uploads/client is for the user side there you have the funcs like download the game 
to the user computer or like change the dir of the installed game , scan for all the games in the pc 
of the user 